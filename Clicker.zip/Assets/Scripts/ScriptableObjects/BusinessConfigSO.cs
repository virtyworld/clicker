using System.Collections.Generic;

using UnityEngine;

[CreateAssetMenu(fileName = "BusinessConfig", menuName = "Configs/Business")]
public class BusinessConfigSO : ScriptableObject
{
    public string businessName;

    [Header("Бизнес параметры")]
    public float incomeDelay;
    public int baseCost;
    public int baseIncome;

    [Header("Улучшение 1")]
    public UpgradeData upgrade1;

    [Header("Улучшение 2")]
    public UpgradeData upgrade2;
}
