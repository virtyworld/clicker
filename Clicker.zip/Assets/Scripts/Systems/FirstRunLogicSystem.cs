using Leopotam.EcsLite;

sealed class FirstRunLogicSystem : IEcsInitSystem
{
    private EcsWorld _world;

    public void Init(IEcsSystems systems)
    {
        _world = systems.GetWorld();

        foreach (var entity in _world.Filter<BusinessComponent>().End())
        {
            ref var business = ref _world.GetPool<BusinessComponent>().Get(entity);
            ref var lvl = ref _world.GetPool<LevelComponent>().Get(entity);

            if (business.id == 0 && lvl.level == 0)
            {
                LvlUpEvent(entity);
            }
        }
    }

    private void LvlUpEvent(int entity)
    {
        ref var lvlUpEvent = ref _world.GetPool<LvlUpEventComponent>().Add(_world.NewEntity());
        lvlUpEvent.businessId = 0;
        lvlUpEvent.ecsPackedEntity = _world.PackEntity(entity);
    }
}
