
struct LvlUpComponent
{
    public int businessId;
    public int cost;
    public BusinessView businessView;
}
