
struct Upgrade2Component
{
    public bool isBought;
    public float incomeMultiplier;
}
