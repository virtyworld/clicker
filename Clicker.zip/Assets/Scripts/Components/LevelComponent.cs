
struct LevelComponent
{
    public int level;  // 0 = не куплен
}
