
using UnityEngine;

struct BusinessComponent
{
    public int id;               // ID бизнеса (0–4)
    public float incomeDelay;    // Задержка дохода (сек)
    public int baseCost;         // Базовая стоимость
    public int baseIncome;       // Базовый доход
    public BusinessView view;
}
