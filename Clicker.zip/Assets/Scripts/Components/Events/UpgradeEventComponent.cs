using Leopotam.EcsLite;
struct UpgradeEventComponent
{
    public int businessId;
    public EcsPackedEntity ecsPackedEntity;
    public int upgradeType; // 1 или 2   
}
