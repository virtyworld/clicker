using Leopotam.EcsLite;

struct SaveGameEventComponent { }