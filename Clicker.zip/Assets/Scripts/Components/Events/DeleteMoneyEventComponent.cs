
struct DeleteMoneyEventComponent
{
    public float money;
}
