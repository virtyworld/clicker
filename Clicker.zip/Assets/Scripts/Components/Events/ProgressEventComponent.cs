using Leopotam.EcsLite;
struct ProgressEventComponent
{
    public EcsPackedEntity ecsPackedEntity;
}
