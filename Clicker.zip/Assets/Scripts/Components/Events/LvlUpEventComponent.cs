using Leopotam.EcsLite;
struct LvlUpEventComponent
{
    public int businessId;
    public EcsPackedEntity ecsPackedEntity;
}
