
struct AddMoneyEventComponent
{
    public float money;
}
