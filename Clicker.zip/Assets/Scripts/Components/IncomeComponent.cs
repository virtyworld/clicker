struct IncomeComponent
{
    public int income;
}
