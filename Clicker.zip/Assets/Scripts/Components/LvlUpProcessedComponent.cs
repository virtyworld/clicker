struct LvlUpProcessedComponent
{
}