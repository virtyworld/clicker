
struct IncomeMultiplierComponent
{
    public float multiplier1; // Например, 0.5f = +50%
    public float multiplier2; // Например, 1.0f = +100%
}
