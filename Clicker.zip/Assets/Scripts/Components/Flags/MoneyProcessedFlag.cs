
struct MoneyProcessedFlag
{
    // add your data here.
}
