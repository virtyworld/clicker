struct LvlUpEventProcessedFlag
{

}
