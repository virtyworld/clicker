
struct ProgressProcessedFlag
{
    // add your data here.
}
