
struct UpgradeProcessedFlag
{
    // add your data here.
}
