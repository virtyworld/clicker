
struct MoneyComponent
{
    public float balance;
}
