
using UnityEngine;
using UnityEngine.UI;

struct ProgressComponent
{
    public int businessId;
    public float currentProgress;
    public float maxProgress;
    public BusinessView businessView;
}
