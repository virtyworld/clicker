
struct Upgrade1Component
{
    public bool isBought;
    public float incomeMultiplier;
}
