
using Leopotam.EcsLite;

using TMPro;

using UnityEngine;
using UnityEngine.UI;

public class BusinessView : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI titleTMP;
    [SerializeField] private Button upgrade1Button;
    [SerializeField] private Button upgrade2Button;
    [SerializeField] private Button lvlUpButton;
    [SerializeField] private TextMeshProUGUI lvlUpButtonText;
    [SerializeField] private Slider progressSlider;
    [SerializeField] private TextMeshProUGUI incomeText;
    [SerializeField] private TextMeshProUGUI lvlText;
    [SerializeField] private TextMeshProUGUI upgrade1TMP;
    [SerializeField] private TextMeshProUGUI upgrade2TMP;

    private int businessId;
    private EcsPackedEntity ecsPackedEntity;
    private EcsWorld _world;
    public void Setup(EcsWorld world, EcsPackedEntity ecsPackedEntity, int businessId)
    {
        this.ecsPackedEntity = ecsPackedEntity;
        this.businessId = businessId;
        _world = world;
        upgrade1Button.onClick.AddListener(OnUpgrade1ButtonClick);
        upgrade2Button.onClick.AddListener(OnUpgrade2ButtonClick);
        lvlUpButton.onClick.AddListener(OnLvlUpButtonClick);
    }

    private void OnUpgrade1ButtonClick()
    {
        ref var uec = ref _world.GetPool<UpgradeEventComponent>().Add(_world.NewEntity());
        uec.businessId = businessId;
        uec.upgradeType = 0;
        uec.ecsPackedEntity = ecsPackedEntity;
    }

    private void OnUpgrade2ButtonClick()
    {
        ref var uec = ref _world.GetPool<UpgradeEventComponent>().Add(_world.NewEntity());
        uec.businessId = businessId;
        uec.upgradeType = 1;
        uec.ecsPackedEntity = ecsPackedEntity;
    }

    private void OnLvlUpButtonClick()
    {
        ref var luec = ref _world.GetPool<LvlUpEventComponent>().Add(_world.NewEntity());
        luec.businessId = businessId;
        luec.ecsPackedEntity = ecsPackedEntity;

    }
    public void UpdateTitle(string text)
    {
        titleTMP.text = text;
    }
    public void UpdateProgress(float value)
    {
        progressSlider.value = value;
    }
    public void UpdateLvl(string text)
    {
        lvlText.text = text;
    }
    public void EnableLvlUpButton()
    {
        lvlUpButton.interactable = true;
    }
    public void DisableLvlUpButton()
    {
        lvlUpButton.interactable = false;
    }
    public void UpdateLvlUpButton(string text)
    {
        lvlUpButtonText.text = text;
    }
    public void UpdateIncome(string text)
    {
        incomeText.text = text;
    }
    public void UpdateUpgrade1(string text)
    {
        upgrade1TMP.text = text;
    }
    public void UpdateUpgrade2(string text)
    {
        upgrade2TMP.text = text;
    }
    public void EnableUpgrade1Button()
    {
        upgrade1Button.interactable = true;
    }
    public void DisableUpgrade1Button()
    {
        upgrade1Button.interactable = false;
    }
    public void EnableUpgrade2Button()
    {
        upgrade2Button.interactable = true;
    }
    public void DisableUpgrade2Button()
    {
        upgrade2Button.interactable = false;
    }

}
