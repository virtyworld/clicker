
[System.Serializable]
public class UpgradeData
{
    public string upgradeName;
    public int price;
    public float incomeMultiplier;
}
